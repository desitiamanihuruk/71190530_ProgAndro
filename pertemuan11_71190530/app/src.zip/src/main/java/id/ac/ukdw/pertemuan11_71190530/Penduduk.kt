package id.ac.ukdw.pertemuan11_71190530

class Penduduk {
    data class Penduduk(val nama: String, val usia: Int)
}